#!/usr/bin/python
import py_compile
print("Hello Multi Universe")
