#Write a program to accept string & a charter or another string and without using count method, count the occurances of second string into first string.
#!/usr/bin/python

