#Write a program to accept 2 number from user & display there addition.

#!/usr/bin/python

iNum1=input("Enter 1st number :")
iNum2=input("Enter 2nd number :")
iNum3=input("Enter 3rd number :")

iResult=iNum1+iNum2+iNum3
print("Sum of {}, {} and {} is {}".format(iNum1,iNum2,iNum3,iResult))
