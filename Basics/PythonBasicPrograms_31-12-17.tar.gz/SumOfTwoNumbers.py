#!/usr/bin/python

iNum1=input("Enter the 1st number :")
iNum2=input("Enter the 2nd number :")
iResult=iNum1+iNum2
print("Addition of {} and {} is :{}".format(iNum1,iNum2,iResult))

