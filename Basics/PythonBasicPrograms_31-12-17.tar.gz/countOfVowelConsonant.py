#Write a program to accept string from user and print how many vovels and consonnts are present in that string. hint: count no.

#!/usr/bin/python
def printCount(string):
	#for x in range(0,len(string),1):
	vowelCount=0
	consonantCount=0
	for char in string:
		if char in "aeiou":
			vowelCount=vowelCount+1
		else:
			consonantCount=consonantCount+1
	print("Vowels :{}".format(vowelCount))
	print("Consonants :{}".format(consonantCount))

def main():
	string=input("Enter the string :")
	printCount(string)

if __name__=="__main__":
	main()
