#!/usr/bin/python
print("This line executes always "+__name__)
def main():
	print("Its Python's main function")
if __name__=='__main__':
	main()
